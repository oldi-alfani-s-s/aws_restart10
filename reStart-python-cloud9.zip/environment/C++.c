#include<stdio.h>

main () {

printf("hello word");

}