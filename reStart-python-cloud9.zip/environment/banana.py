myString = "This is a string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))

firstString = "water"
secondString = " fall"
thirdString = firstString + secondString
print(thirdString)

name = input("masukan nama = ")
print("hello my name is " + name )

color = input ("what is your favorite color ? ")
animal = input ("whats is your favorite animal? ")

strings_jelas = " i have a favorite color, that " + color + " and i have a favorite animal, that's a " + animal 
print(strings_jelas)