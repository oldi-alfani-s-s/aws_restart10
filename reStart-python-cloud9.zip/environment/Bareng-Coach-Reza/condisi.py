 angka = input("masukan nilai kamu ! = ")

if angka > 80:
    print("selamat kamu lulus dengan nilai A")
elif angka > 100:
    print("yang bener ajg!! inputnya ")
elif angka > 60 :
    print("selamat kamu lulus dengan nilai B")
else:
    ("lu gak lulus!!! Makanya Belajar")
    