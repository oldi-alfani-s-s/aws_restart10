import array as arr

myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
print(myFruitList[0])

myFruitList[0] = "orange"
myFruitList[1] = "kiwi"
myFruitList[2] = "strawberry\n"
print(myFruitList)
print(myFruitList[2])

group = [
    ["oldi","iwan","bape"],
    ["yawa","anwar","rawwe"]
    ]
    
print(group[0][2])

myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))
print(myFinalAnswerTuple[0])

myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))

print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])

print("\n set :")
mySet= {1,2,2,4}
print(mySet)